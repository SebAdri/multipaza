@extends('cabecera')

@section('contenido')

<table>
	<thead>

		<tr>
			<td>Modulo</td>	
		</tr>
	</thead>
	<tbody>
		<tr>
			
		</tr>
	</tbody>
</table>
@endsection