@extends('cabecera')

@section('contenido')
<div class="form-control">

<h1>Bienvenido</h1>
</div>


@endsection