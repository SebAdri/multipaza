<!-- Modal -->
  <div class="modal-dialog" role="document">
    <div class="modal-content panel-danger">
      <div class="modal-header panel-heading">
        <h2 class="modal-title" id="exampleModalLabel"><strong>ATENCIÓN</strong></h2>
      </div>
      <div class="modal-body">
        <h4 class="modal-body">Está seguro que desea eliminar este registro. Esto podría afectar el funcionamiento el sistema?</h4>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-danger">Confirmar</button>
      </div>
    </div>
  </div>
</div>